# Audit & perbaikan v11.29.1

Tanggal audit: 10 Oktober 2026. Paket ini adalah source/prebuild, bukan executable Windows.

## Bukti penyebab pairing
- Log live Supabase untuk build Electron `ani-games-billing-v11/11.29.0` menunjukkan POST ke `/functions/v1/ani-games-api/device/enroll` dan endpoint sync menerima HTTP 401 dengan `UNAUTHORIZED_INVALID_API_KEY`, `Invalid API key`, dan `apikey.error=bad_length`. Respons ditolak oleh gateway sebelum fungsi Edge Function menjalankan `redeem_device`.
- Aplikasi memakai key client `sb_publishable_*` yang berformat 47 karakter tersebut. Source PC dan Web Admin kini menggunakan legacy public `anon` key yang terdaftar aktif di proyek yang sama dan kompatibel dengan API gateway ini. Tidak ada `service_role` key dimasukkan ke paket. Token device tetap digunakan untuk semua endpoint sinkronisasi.
- Fungsi Edge `ani-games-api` pada proyek aktif dan `verify_jwt=false`; fungsi memvalidasi kode pairing/token device di lapisan aplikasi/SQL. Jangan mengubah `verify_jwt` tanpa desain autentikasi yang sesuai.

## Perbaikan source
1. Mengganti API key untuk PC cloud client dan Web Admin dengan active legacy anon key setelah mencocokkan project ref.
2. Menambah aksi **Edit** pada daftar user PC, form mengganti sisa durasi/kategori/expiry secara absolut, tidak menambah durasi, mempertahankan kode, menghalangi edit/hapus saat akun sedang aktif, menandai perubahan sebagai dirty dan menunggu mekanisme sinkronisasi cloud yang ada.
3. Daftar Akun Rental Web Admin sekarang membaca `api.admin_rental_accounts` untuk PC terpilih, menampilkan saldo/status/label aktual, dan menggunakan `api.admin_edit_rental` untuk menyimpan data serta memasukkan command `upsert_rental` ke antrean dan mencatat audit server. RPC menolak perubahan waktu saat sesi aktif/paused.
4. Memisahkan tabel statistik laporan dari tabel saldo rental. Sebelumnya `accountRows` diisi dari laporan jam terpakai/event, tetapi ditaruh di tabel yang judul kolomnya Sisa/Status/Client; sekarang laporan dan saldo cloud di-render terpisah.
5. Membangun baris PC rental menggunakan DOM/textContent agar kode user tidak dirender sebagai HTML mentah.
6. Menyelaraskan source Edge Function `device/ack` dengan perilaku versi live v7: ACK fase `acknowledged` menandakan command diterima, bukan selesai; proses finalisasi trial baru berjalan pada status final (`completed`, `failed`, `expired`). Ini mencegah trial dianggap selesai saat command baru dikirim.
7. Memperbaiki penghitungan tanggal otomatis masa aktif untuk input `datetime-local` supaya menggunakan jam lokal, bukan string UTC yang dipotong.

## Audit Supabase tambahan
- Security advisor menemukan peringatan `auth_leaked_password_protection` masih nonaktif. Disarankan mengaktifkan perlindungan password bocor pada Auth Settings.
- Dua tabel billing-control (`billing_control_accounts` dan `billing_control_sessions`) memiliki RLS aktif tanpa policy langsung. Ini menghalangi akses langsung via role client; aksesnya harus tetap melalui RPC `SECURITY DEFINER` yang memvalidasi session. Jangan menambahkan policy umum tanpa review akses.
- Performance advisor menandai 22 index sebagai belum pernah dipakai. Tidak dihapus dalam paket ini karena statistik pemakaian dapat belum matang dan penghapusan membutuhkan kajian query produksi.

## Pemeriksaan setelah perubahan
- Menjalankan pemeriksaan sintaks JavaScript untuk renderer cloud dan ekstraksi inline script HTML.
- Memastikan tidak ada key `sb_publishable_*` lama tersisa di source runtime.
- Memvalidasi struktur ZIP dan daftar file.
- Tes pairing fisik dari PC pengguna tidak dapat dijalankan dari lingkungan build ini. Setelah install/build paket, lakukan pairing baru dengan kode yang belum kedaluwarsa; keberhasilan final harus dibuktikan oleh dialog sukses dan perangkat berstatus online/heartbeat terbaru di Supabase.

## Batasan / catatan audit
- Build `.exe` Windows tidak dihasilkan di lingkungan ini (dependency npm/electron-builder tidak tersedia offline). Paket keluaran tetap source/prebuild.
- Jangan menyimpan `service_role` key di aplikasi klien.
- `device/enroll` hanya menerima kode enrollment; setelah pairing, sinkronisasi PC memakai token perangkat yang dikeluarkan server.


## v11.29.3 pairing re-audit
- Fixed second failure `duplicate key value violates unique constraint device_tokens_device_id_key` by rotating the existing device token row in-place.
- Merged verified empty registration `PC-E30A5209` as an alias to `PC-38BFEEB2`; retained audit history and all 29 rental accounts.
- Cloud snapshot now precedes first local outbox reconciliation when a known PC identity is resumed; cloud-existing rental codes take cloud values and stale queued writes for those codes are dropped.
- New PC with distinct client ID still requires unused enrollment code and creates its own unit.
