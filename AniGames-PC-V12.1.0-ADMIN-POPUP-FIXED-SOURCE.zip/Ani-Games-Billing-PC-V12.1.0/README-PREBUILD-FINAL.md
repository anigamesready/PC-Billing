# Ani Games Billing PC — PRE-BUILD FINAL v11.29.3

**Ini source project untuk build Windows portable, bukan EXE yang sudah dikompilasi.**

## Perubahan versi ini
- Pairing pada PC dengan `client_id` kanonis atau alias yang sudah diaudit melanjutkan satu baris perangkat lama.
- Rotasi token memperbarui satu baris di `device_tokens` (termasuk baris yang sudah dicabut), tidak mencoba membuat baris kedua untuk `device_id` yang sama.
- Saat pairing memulihkan PC lama, snapshot rental Supabase dimuat lebih dahulu; event lokal lama untuk akun yang sudah ada di cloud dibersihkan dari outbox agar nilai lama tidak langsung menimpa cloud.
- PC baru dengan identitas berbeda tetap menjadi unit terpisah jika memakai kode pairing yang valid dan belum digunakan.
- Menu Edit Rental dari versi sebelumnya dipertahankan.
- Runtime PC API tetap diarahkan langsung ke Supabase Edge Function `ani-games-api`.

## Status data proyek saat audit
- Satu baris perangkat kanonis: `PC-38BFEEB2`, dengan alias lama `PC-E30A5209`.
- Ada 29 baris `rental_accounts` di PC kanonis; satu adalah placeholder internal `__TEST10__` berstatus disabled yang sengaja tidak dikirim sebagai rental pelanggan. Snapshot PC mengembalikan 28 akun rental nyata. 72 sesi, 35 transaksi, 11.809 heartbeat, dan riwayat audit dipertahankan.
- Registrasi PC kosong dengan ID alias digabung; token kosong/revoked lama ikut dibersihkan via FK cascade. Riwayat audit tidak dihapus.
- Tidak ditemukan kode rental duplikat yang aktif/terdaftar (kecuali placeholder tes `__TEST10__`).

## Build Windows
Gunakan Windows x64 dengan Node.js LTS dan internet aktif:
```powershell
npm ci
npm run build
```
File `.exe` portable dibuat di `dist/`.

## Penting
1. Gunakan kode pairing baru yang valid dari Web Admin jika kode sebelumnya kedaluwarsa.
2. Identitas lama `PC-E30A5209` dikenali sebagai alias PC kanonis; pairing harus mengembalikan `resumed_existing: true` dan memuat snapshot cloud 29 akun.
3. PC baru dengan ID lain membutuhkan kode baru yang belum digunakan dan dibuat sebagai unit terpisah.
4. Jangan hapus data lokal sebelum pairing, Full Sync, dan pemeriksaan saldo selesai.
5. Ini paket source/prebuild; uji terakhir tetap harus dilakukan pada PC Windows target. Build statis dan transaksi uji Supabase bukan pengganti tes desktop end-to-end.

Lihat `PAIRING-FIX-v11.29.3.md`, `SUPABASE-DIRECT-MIGRATION-v11.29.3.md`, dan `docs/V11.29.3-PAIRING-TOKEN-ROTATION-AND-MERGE.sql`.


## V12.1.0 additive test overlay
- This is a separate test build (`Ani Games Billing V12 Test`, appId `com.anigames.billing.v12test`) so it does not share installation identity with V11.
- `index.html` adds one receiver command `show_admin_message` that uses the existing notification modal and does not change timer/rental/pairing state.
- To enable sending, apply `../docs/v12.1.0_enable_admin_chat.sql` to both DB1 and DB2. That migration is not applied automatically.
- Build and test on a non-production PC or a separately paired test PC before considering release.
