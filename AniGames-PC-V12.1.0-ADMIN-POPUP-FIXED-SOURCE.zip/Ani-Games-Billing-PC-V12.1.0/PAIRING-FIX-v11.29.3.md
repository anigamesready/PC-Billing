# v11.29.3 — Pairing resume, one-token-per-PC, cloud-first restore

## Root causes found by repeated audit
1. `devices_org_id_client_id_key`: retry pairing tried to create a second `devices` row for the same organization + client ID.
2. After the first fix, the next retry failed on `device_tokens_device_id_key`: code revoked the old token row and then INSERTed another row even though `device_tokens.device_id` is unique. Correct behavior is to UPDATE the existing row's `token_hash`, `created_at`, and `revoked_at=NULL`; INSERT only if no row exists.
3. Before this version, local dirty/outbox values could prevent a recovered PC from loading its cloud snapshot or could immediately overwrite cloud accounts after re-pair.

## Production changes
- `api.redeem_device` now recognizes canonical `client_id` and approved `metadata.clientIdAliases`.
- A resumed PC keeps its canonical device UUID and rental/session/billing history.
- Token rotates in place; only one `device_tokens` row remains per device.
- A code already bound to a different device is rejected. A distinct new PC ID requires a fresh unused pairing code and creates a separate device.
- On resumed pairing, client loads the full rental snapshot before the first heartbeat/reconcile sync; outbox events for account codes already resolved from cloud are discarded to prevent stale values overwriting cloud state. Local-only rental codes are retained and reconciled after snapshot succeeds.
- Empty stale registration `PC-E30A5209` was merged into canonical device `PC-38BFEEB2` as a persisted alias. It had no rental/session/transaction/usage/command/heartbeat/command-log/trial/admin-access data. Original audit rows were retained and a merge audit record was added.
- Added an index on `device_enrollments.redeemed_device_id` to address the database performance advisor's unindexed-FK finding.

## Transactional test
A rolled-back SQL test exercised: same PC identity continues same device; token is updated in the existing row; exactly one token row remains; used code is rejected for another identity; unused code creates a new device. No test rows were committed.

## Verification boundary
Production SQL definition and data counts were queried after migration. JavaScript syntax checks passed. Pairing through the actual Windows desktop and end-to-end Full Sync still must be confirmed on the target PC; do not interpret static/transactional tests as a physical-device success claim.
