-- AniGames V12.1.0 additive Admin -> Windows popup message support.
-- AUDIT: DB1 and DB2 had identical function bodies and device_commands constraints.
-- Apply this migration separately to DB1 and DB2 ONLY when ready to enable chat.
-- Does not modify rental/timer/pairing/PC-control command behavior.

begin;

alter table public.device_commands
  drop constraint if exists device_commands_command_check;

alter table public.device_commands
  add constraint device_commands_command_check
  check (command = any (array[
    'restart_billing'::text,
    'restart_pc'::text,
    'restart'::text,
    'logoff'::text,
    'logout'::text,
    'pause'::text,
    'resume'::text,
    'stop'::text,
    'shutdown'::text,
    'add_time'::text,
    'set_theme'::text,
    'refresh'::text,
    'wake'::text,
    'upsert_rental'::text,
    'start_trial'::text,
    'delete_rental'::text,
    'show_admin_message'::text
  ]));

create or replace function api.admin_command(
  p_org_id uuid,
  p_device_id uuid,
  p_command text,
  p_payload jsonb default '{}'::jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_catalog
as $function$
declare
  a public.admin_accounts%rowtype;
  d public.devices%rowtype;
  s public.rental_sessions%rowtype;
  cid uuid;
  sid uuid;
begin
  if auth.uid() is null then raise exception 'UNAUTHENTICATED'; end if;

  select * into a
  from public.admin_accounts
  where auth_user_id = auth.uid() and status = 'active'
  limit 1;

  if not found then raise exception 'ADMIN_ACCOUNT_NOT_CONFIGURED'; end if;
  if a.role <> 'SUPER_ADMIN' and a.org_id is distinct from p_org_id then
    raise exception 'ORG_ACCESS_DENIED';
  end if;

  select * into d
  from public.devices
  where id = p_device_id and org_id = p_org_id
  limit 1;

  if not found or not private.admin_can_access_device(p_device_id, p_org_id) then
    raise exception 'DEVICE_ACCESS_DENIED';
  end if;
  if d.status = 'disabled' then raise exception 'DEVICE_DISABLED'; end if;
  if coalesce(d.last_heartbeat_at, d.last_seen_at) is null
     or coalesce(d.last_heartbeat_at, d.last_seen_at) < now() - interval '45 seconds'
     or d.status <> 'online' then
    raise exception 'PC_OFFLINE_COMMAND_BLOCKED';
  end if;

  if p_command not in (
    'restart_billing','restart_pc','restart','logoff','logout','pause','resume',
    'stop','shutdown','refresh','wake','add_time','show_admin_message'
  ) then
    raise exception 'COMMAND_NOT_ALLOWED';
  end if;

  if p_command = 'show_admin_message'
     and length(btrim(coalesce(p_payload->>'message',''))) not between 1 and 240 then
    raise exception 'INVALID_ADMIN_MESSAGE';
  end if;

  if p_command in ('pause','resume','stop') then
    if nullif(p_payload->>'session_id','') is null then
      raise exception 'SESSION_ID_REQUIRED';
    end if;
    sid := (p_payload->>'session_id')::uuid;
    select * into s
    from public.rental_sessions
    where id = sid and org_id = p_org_id and device_id = p_device_id
    for update;
    if not found then raise exception 'SESSION_NOT_FOUND'; end if;
    if p_command = 'pause' and s.status <> 'active' then raise exception 'SESSION_NOT_ACTIVE'; end if;
    if p_command = 'resume' and s.status <> 'paused' then raise exception 'SESSION_NOT_PAUSED'; end if;
    if p_command = 'stop' and s.status not in ('active','paused') then raise exception 'SESSION_NOT_OPEN'; end if;
  end if;

  insert into public.device_commands(org_id, device_id, command, payload, status, created_by)
  values (p_org_id, p_device_id, p_command, coalesce(p_payload,'{}'::jsonb), 'queued', auth.uid())
  returning id into cid;

  insert into public.audit_logs(org_id, actor_user_id, action, target_type, target_id, payload)
  values (
    p_org_id, auth.uid(), 'remote_command', 'device', p_device_id::text,
    jsonb_build_object('command',p_command,'command_id',cid,'payload',coalesce(p_payload,'{}'::jsonb))
  );

  return jsonb_build_object('ok',true,'command_id',cid,'device_id',p_device_id,'command',p_command);
end;
$function$;

create or replace function api.queue_command(
  p_org_id uuid,
  p_device_id uuid,
  p_command text,
  p_payload jsonb default '{}'::jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_catalog
as $function$
declare
  uid uuid := auth.uid();
  cid uuid;
begin
  if uid is null then raise exception 'AUTH_REQUIRED'; end if;
  if not private.is_owner_access(p_org_id) then raise exception 'OWNER_ONLY'; end if;
  if not exists(select 1 from public.devices where id=p_device_id and org_id=p_org_id) then
    raise exception 'DEVICE_NOT_FOUND';
  end if;

  if p_command not in (
    'restart_billing','restart_pc','restart','logoff','logout','pause','resume',
    'stop','shutdown','add_time','set_theme','refresh','wake','upsert_rental','show_admin_message'
  ) then
    raise exception 'INVALID_COMMAND';
  end if;

  if p_command = 'show_admin_message'
     and length(btrim(coalesce(p_payload->>'message',''))) not between 1 and 240 then
    raise exception 'INVALID_ADMIN_MESSAGE';
  end if;

  insert into public.device_commands(org_id,device_id,command,payload,status,created_by)
  values(p_org_id,p_device_id,p_command,coalesce(p_payload,'{}'::jsonb),'queued',uid)
  returning id into cid;

  insert into public.device_command_logs(command_id,org_id,device_id,status,result)
  values(cid,p_org_id,p_device_id,'queued',coalesce(p_payload,'{}'::jsonb));

  insert into public.audit_logs(org_id,actor_user_id,action,target_type,target_id,payload)
  values(p_org_id,uid,'queue_device_command','device_command',cid,
         jsonb_build_object('command',p_command,'device_id',p_device_id));

  return jsonb_build_object('command_id',cid,'status','queued');
end;
$function$;

commit;
