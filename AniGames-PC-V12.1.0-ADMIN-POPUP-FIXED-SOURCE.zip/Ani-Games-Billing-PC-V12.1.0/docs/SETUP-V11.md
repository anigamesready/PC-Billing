# Setup V11.29.0 — Supabase Direct

- Runtime cloud API: Supabase Edge Function `https://wzkjpycjizexxcxrfdvr.supabase.co/functions/v1/ani-games-api`.
- Authentication, rentals, reports, organizations, devices, and Billing Control continue using existing Supabase Auth / `api`-schema RPCs.
- PC billing remains offline-first: timer and local database stay on the PC; changes queue locally and sync when internet returns.
- Do not expose any Supabase secret/service-role key in client-side files or APKs.
- See `SUPABASE-DIRECT-MIGRATION-v11.29.1.md` for endpoint list, data safety and build steps.
