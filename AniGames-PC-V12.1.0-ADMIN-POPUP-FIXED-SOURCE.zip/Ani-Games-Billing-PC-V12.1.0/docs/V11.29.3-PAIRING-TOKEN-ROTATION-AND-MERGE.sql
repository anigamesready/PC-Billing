-- Ani Games Billing v11.29.3 pairing resume/token rotation.
-- Project-specific production repair: wzkjpycjizexxcxrfdvr.
-- The merge block is guarded: it only merges the known EMPTY registration PC-E30A5209 into PC-38BFEEB2.

create index if not exists idx_device_enrollments_redeemed_device_id
  on public.device_enrollments(redeemed_device_id);

create or replace function api.redeem_device(
  p_code text, p_client_id text, p_device_name text, p_app_version text
) returns jsonb
language plpgsql security definer
set search_path to 'public','pg_catalog'
as $function$
declare
  e public.device_enrollments%rowtype;
  d public.devices%rowtype;
  v_token text;
  v_token_hash text;
  is_existing boolean := false;
  token_rows integer := 0;
begin
  if coalesce(trim(p_client_id),'')='' then raise exception 'CLIENT_ID_REQUIRED'; end if;

  select * into e from public.device_enrollments
  where code_hash=encode(extensions.digest(upper(trim(p_code)),'sha256'),'hex')
    and (expires_at is null or expires_at>now())
  order by created_at desc limit 1 for update;
  if not found then raise exception 'INVALID_ENROLLMENT'; end if;

  select * into d from public.devices
  where org_id=e.org_id
    and (client_id=trim(p_client_id)
      or coalesce(metadata->'clientIdAliases','[]'::jsonb) ? trim(p_client_id))
  order by case when client_id=trim(p_client_id) then 0 else 1 end, created_at asc
  limit 1 for update;

  if found then
    is_existing := true;
    if e.used_at is not null and e.redeemed_device_id is not null and e.redeemed_device_id<>d.id then
      raise exception 'INVALID_ENROLLMENT';
    end if;
    update public.devices
    set device_name=case when client_id=trim(p_client_id)
                         then coalesce(nullif(trim(p_device_name),''),device_name)
                         else device_name end,
        app_version=coalesce(nullif(trim(p_app_version),''),app_version),
        status='online', last_seen_at=now(),
        metadata=coalesce(metadata,'{}'::jsonb)
          || jsonb_build_object('last_repaired_at',now(),'pairing_mode','resume-existing')
    where id=d.id;
    update public.device_enrollments
    set used_at=coalesce(used_at,now()), redeemed_device_id=coalesce(redeemed_device_id,d.id)
    where id=e.id;
  else
    if e.used_at is not null then raise exception 'INVALID_ENROLLMENT'; end if;
    insert into public.devices(org_id,client_id,device_name,status,app_version,last_seen_at,metadata)
    values(e.org_id,trim(p_client_id),coalesce(nullif(trim(p_device_name),''),trim(p_client_id)),
           'online',nullif(trim(p_app_version),''),now(),jsonb_build_object('enrolled_at',now()))
    returning * into d;
    update public.device_enrollments set used_at=now(),redeemed_device_id=d.id where id=e.id;
  end if;

  v_token:=replace(gen_random_uuid()::text||gen_random_uuid()::text,'-','');
  v_token_hash:=encode(extensions.digest(v_token,'sha256'),'hex');
  update public.device_tokens
  set token_hash=v_token_hash, created_at=now(), revoked_at=null
  where device_id=d.id;
  get diagnostics token_rows=row_count;
  if token_rows=0 then
    insert into public.device_tokens(device_id,token_hash) values(d.id,v_token_hash);
  end if;

  insert into public.audit_logs(org_id,actor_device_id,action,target_type,target_id,payload)
  values(e.org_id,d.id,case when is_existing then 'device_repaired' else 'device_enrolled' end,
         'device',d.id::text,jsonb_build_object('client_id',p_client_id,'device_name',p_device_name,
         'resumed_existing',is_existing,'token_rotated_in_place',token_rows>0));
  return jsonb_build_object('device_id',d.id,'org_id',d.org_id,'token',v_token,
      'client_id',p_client_id,'resumed_existing',is_existing,'token_rotated_in_place',token_rows>0);
end
$function$;

-- Safe, idempotent merge of the verified empty duplicate/stale pairing row.
-- Refuses to delete if any operational data is attached. Existing audit history is retained.
do $merge$
declare old public.devices%rowtype; canon public.devices%rowtype; aliases jsonb;
begin
  select * into old from public.devices
  where id='5388753f-7f3e-4957-b105-8f4ba5daa81f'::uuid and client_id='PC-E30A5209' for update;
  if found then
    select * into canon from public.devices
    where id='c30ddea5-2630-42dd-8980-89261b95defd'::uuid
      and org_id=old.org_id and client_id='PC-38BFEEB2' for update;
    if not found then raise exception 'CANONICAL_PC_NOT_FOUND'; end if;
    if exists(select 1 from public.rental_accounts where device_id=old.id)
       or exists(select 1 from public.rental_sessions where device_id=old.id)
       or exists(select 1 from public.billing_transactions where device_id=old.id)
       or exists(select 1 from public.usage_events where device_id=old.id)
       or exists(select 1 from public.device_commands where device_id=old.id)
       or exists(select 1 from public.device_heartbeats where device_id=old.id)
       or exists(select 1 from public.device_command_logs where device_id=old.id)
       or exists(select 1 from public.device_trial_requests where device_id=old.id)
       or exists(select 1 from public.admin_pc_access where device_id=old.id)
       or exists(select 1 from public.device_enrollments where redeemed_device_id=old.id) then
      raise exception 'REFUSE_MERGE_NONEMPTY_PC';
    end if;
    select coalesce(jsonb_agg(to_jsonb(alias) order by alias),'[]'::jsonb) into aliases
    from (select jsonb_array_elements_text(coalesce(canon.metadata->'clientIdAliases','[]'::jsonb)) alias
          union select old.client_id alias) q;
    update public.devices set metadata=coalesce(metadata,'{}'::jsonb)||jsonb_build_object(
      'clientIdAliases',aliases,
      'pairingMergeAudit',jsonb_build_object('mergedDeviceId',old.id::text,
      'mergedClientId',old.client_id,'mergedAt',now(),
      'reason','empty failed pairing registration merged into canonical PC',
      'auditRowsPreserved',true)) where id=canon.id;
    update public.device_enrollments
    set redeemed_device_id=canon.id
    where org_id=canon.org_id
      and id in ('022b067c-6c6c-4858-bcf1-092c1b66b52e'::uuid,
                 'dec17203-7c0b-4e4c-918c-813b6de5af7d'::uuid)
      and used_at is not null and redeemed_device_id is null;
    insert into public.audit_logs(org_id,action,target_type,target_id,payload)
    values(canon.org_id,'device_record_merged','device',old.id::text,
      jsonb_build_object('merged_into_device_id',canon.id,'merged_from_client_id',old.client_id,
      'canonical_client_id',canon.client_id,'reason','empty failed pairing registration',
      'removed_token_rows',(select count(*) from public.device_tokens where device_id=old.id),
      'audit_history_preserved',true));
    delete from public.devices where id=old.id;
  end if;
end
$merge$;
