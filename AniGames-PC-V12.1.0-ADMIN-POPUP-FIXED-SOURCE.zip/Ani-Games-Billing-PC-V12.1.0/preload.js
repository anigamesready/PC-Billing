const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
    setLockMode: (isLocked) => ipcRenderer.send('set-lock-mode', Boolean(isLocked)),
    showAdminMessage: (message) => ipcRenderer.invoke('show-admin-message', String(message || '').slice(0, 240)),
    resizeTimerWindow: (width, height) => ipcRenderer.send('resize-timer-window', Number(width), Number(height)),
    minimizeTimerWindow: () => ipcRenderer.send('minimize-timer-window'),
    restoreTimerWindow: () => ipcRenderer.send('restore-timer-window'),
    powerAction: (action) => ipcRenderer.invoke('power-action', String(action)),
    setDesktopWallpaper: (dataUrl) => ipcRenderer.invoke('set-desktop-wallpaper', String(dataUrl || '')),
    restartBilling: () => ipcRenderer.invoke('restart-billing'),
    exitBilling: () => ipcRenderer.invoke('exit-billing'),
    writeBackup: (payload) => ipcRenderer.invoke('write-backup', payload),
    restoreBackup: () => ipcRenderer.invoke('restore-backup'),
    startFullBackup: (payload) => ipcRenderer.invoke('start-full-backup', payload),
    writeFullBackupMedia: (payload) => ipcRenderer.invoke('write-full-backup-media', payload),
    finishFullBackup: (payload) => ipcRenderer.invoke('finish-full-backup', payload),
    restoreFullBackup: () => ipcRenderer.invoke('restore-full-backup'),
    readBackupFile: (filePath) => ipcRenderer.invoke('read-backup-file', String(filePath || ''))
});