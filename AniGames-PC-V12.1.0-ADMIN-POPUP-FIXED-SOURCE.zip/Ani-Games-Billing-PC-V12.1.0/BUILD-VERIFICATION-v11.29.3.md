# Build / Pairing Verification v11.29.3

## Passed
- `node --check` on `v11-cloud.js`, `renderer.js`, `main.js`, and `preload.js`.
- Supabase `api.redeem_device` source checked after deployment of database RPC.
- Rollback-only database test passed for: same canonical client ID resumes; alias client ID resumes canonical PC; token hash rotates in-place and leaves one token row; a used code is rejected for another PC ID; a new unused code creates a distinct PC row.
- Production database audit after merge: one canonical device row remains; its alias list contains `PC-E30A5209`; 29 `rental_accounts` rows remain attached to canonical PC (28 customer accounts returned by snapshot because the disabled `__TEST10__` trial placeholder is intentionally excluded), plus 72 sessions, 35 transactions, and 11,809 heartbeats; one token row and one active token are present.
- Duplicate rental-code audit returned zero duplicate code groups (excluding the internal `__TEST10__` placeholder).
- ZIP archive integrity check passed (`unzip -t`, no errors).

## Not yet confirmed
- A real desktop pairing + cloud snapshot on the user's actual Windows PC was not executable from this environment. Do not treat static syntax and rollback-only SQL tests as end-to-end success.
- Security advisor still flags leaked-password protection disabled; RLS-on-no-policy INFO exists for `billing_control_accounts` and `billing_control_sessions`. These were not altered in this pairing fix because doing so changes auth/security behavior outside pairing.
