# Pairing Audit Report v11.29.3 — 10 October 2026

## Confirmed causes
1. **`devices_org_id_client_id_key`**: first attempts tried to insert a new device record for an already-registered organization/client identity. Existing identity must resume the existing `devices.id`.
2. **`device_tokens_device_id_key`**: the first retry fix revoked the current token, then attempted a second `device_tokens` row for the same device. The table is unique per device. Corrected flow updates `token_hash`, `created_at`, and `revoked_at=NULL` in the existing row, inserting only if there was no row.
3. **Stale local data risk**: previous client could skip cloud rows when local state was considered dirty and later replay an old queued upsert. For resumed identities, cloud snapshot now takes precedence for codes already present in cloud; those obsolete queued writes are removed, while local-only codes are retained for later reconciliation.

## Production database audit / controlled merge
- Canonical PC: `PC-38BFEEB2` / device UUID `c30ddea5-2630-42dd-8980-89261b95defd`.
- Alias PC ID merged: `PC-E30A5209` / device UUID `5388753f-7f3e-4957-b105-8f4ba5daa81f`.
- Before merge the alias registration had one revoked token row and two audit events, but zero rental accounts, sessions, billing transactions, usage events, commands, heartbeats, command logs, trial requests, admin-PC access links, and redeemed-enrollment references. It was safe to merge into the data-bearing PC, not safe to drop as if its historical audit never occurred.
- Alias `PC-E30A5209` is now stored in canonical device metadata. This lets the same installation ID recover the same 29 `rental_accounts` rows. Its two original audit events remain; a merge audit event was added.
- Current canonical database audit: 29 rows in `rental_accounts`, 72 sessions, 35 transactions, 11,809 heartbeats; one token row and one active token. The 29 rental rows include one disabled internal `__TEST10__` placeholder, intentionally excluded by the device snapshot RPC. Therefore the PC snapshot contains 28 actual rental accounts.
- No exact duplicate `org_id + client_id` pairs and no duplicate rental codes were found. The empty registration was merged because it was confirmed to be a failed/stale attempt and had no operational records.

## Transactional regression tests (all rolled back)
- Same/alias identity: returned the canonical device UUID with `resumed_existing=true`.
- Token rotation: returned `token_rotated_in_place=true`; exactly one device token row remained.
- Cloud snapshot: returned 28 customer rental accounts; excluded the disabled trial placeholder.
- Reuse of a used code for a different PC ID: rejected as `INVALID_ENROLLMENT`.
- New PC with a separate unused code: created a different device UUID and returned an empty snapshot, with no accounts inherited from the canonical PC.
- Test-created enrollment, devices, tokens, and audit entries were rolled back and not committed.

## Other advisor findings
- Security advisor: leaked-password protection disabled (warning); RLS enabled without direct policies on `billing_control_accounts` and `billing_control_sessions` (informational). These are outside pairing scope and were not changed.
- Performance advisor: index on `device_enrollments.redeemed_device_id` was added. Unused-index notices remain informational and were not removed automatically.

## Final limitations
- Syntax checks and controlled SQL regression tests passed.
- This environment cannot run the actual Windows Electron client, so a live PC pairing/network end-to-end check is still required before calling desktop pairing fully proven. Use a **new unexpired pairing code** on the PC, then check that it resumes the canonical PC and reports 28 rental accounts synced.
