# AniGames PC V12.1.1 — dedicated Admin popup window

## Patch applied
- `main.js`: adds a dedicated Electron `BrowserWindow` for Admin messages, independent of the compact timer window.
- `preload.js`: exposes a narrowly scoped `showAdminMessage()` IPC call.
- `index.html`: `show_admin_message` awaits the separate-window result and only acknowledges success when Electron reports the window shown. It no longer relies on the login-page modal or browser `alert()`.
- Message text is limited to 240 characters and HTML-escaped before rendering.
- Rental timer calculations, rental rows, pairing identity, and billing state logic were not intentionally changed.

## Build on Windows
Use Node.js 20 LTS in this folder:

```powershell
npm ci
npm run build
```

The portable EXE should be created in `dist/`.

## Verification boundary
Source archive integrity and JavaScript syntax are checked. This environment cannot run the Windows Electron GUI, so the actual visible-popup test must be confirmed on the test PC:
1. Build and launch the V12.1.1 test app.
2. Start a test rental timer.
3. Send `show_admin_message` from Admin while the timer is running.
4. Confirm the separate message window appears, timer continues counting, and Admin command status becomes completed.
5. Repeat at the billing login screen.
Keep the locked V11.29.3 production installation intact until those checks pass. This is a source patch, not a compiled EXE or proof of GUI end-to-end testing.
